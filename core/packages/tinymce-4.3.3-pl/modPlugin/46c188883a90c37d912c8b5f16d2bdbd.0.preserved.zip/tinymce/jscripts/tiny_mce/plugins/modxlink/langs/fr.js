tinyMCE.addI18n('fr.modxlink',{
    link_desc:"Insert/edit link"
});