--------------------
Snippet: FileLister
--------------------
Version: 1.0
Since: June 25, 2009-2010
Author: Shaun McCormick <shaun@modxcms.com>

A file listing Snippet for MODx Revolution.

Official Documentation:
http://svn.modxcms.com/docs/display/ADDON/FileLister